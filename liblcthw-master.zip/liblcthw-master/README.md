LibLCTHW
========

This is the library that you finally create in my book Learn C The Hard Way found at:

http://c.learncodethehardway.org/

This code is usually in sync with the book, but sometimes it gets out of sync during editing sessions.  If you find a difference or a bug, just submit your pull request and I'll take a look.

